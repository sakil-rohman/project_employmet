import CmsApp from './routes/cms_routes'
import MyApp from './routes/myapp_routes'
import {useState, useContext, createContext} from 'react'


// function App() {
//   return (
//     <div>
    

      
//       <Header />
//       <BrowserRouter>
//       <Routes>
//       <Route path="/" element={<Home />} />
//       <Route path="/guidelines" element={<Guidelines />} />
//       <Route path="/guidelines2" element={<Guidelines2 />} />
//       <Route path="/contactus" element={<Contactus />} />
//       <Route path="/gallery" element={<Gallery />} />
//           {/* <main className='content'> */}
//       {/* <Slider /> */}
//        {/* <Midcard /> */}
//       {/* <Mapelocation />  */}
//       {/* </main> */}
     
//       {/* <Route path="/guidlines">
//               <Guidlines />
//       </Route>   */}
//       </Routes>
//       </BrowserRouter>
      
//     <FooTer />
//     </div>
//   );
// }
const UserStateContext= createContext(null)
const dispatchStateContext= createContext(null)
function App() {
  const [isCms, setIsCms]= useState(false)
  return (
    <UserStateContext.Provider value={isCms} >
      <dispatchStateContext.Provider value={setIsCms}> 
        {/* <MyApp /> */}
        <CmsApp />
      </dispatchStateContext.Provider>
   
    </UserStateContext.Provider>
  );
}


export default App;
