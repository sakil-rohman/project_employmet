import Header from '../components/Header'
import Home from '../components/Home'
import FooTer from '../components/Footer'
import Mapelocation from '../components/Mapelocation'
import Midcard from '../components/Midcard'
import '../App.css';
// import Button from 'react-bootstrap/Button';
// import { Carousel } from 'react-bootstrap'
import '../bootstrap.min.css'
import Guidelines from '../components/Guidelines'
import Guidelines2 from '../components/Guidelines2 copy'
import Contactus from '../components/Contactus'
// import Footer_s from './components/Footer';
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Gallery from '../components/gallery'
import Login from '../components/Login'
import Registration from '../components/Registration'

import '../bootstrap.min.css';
import AboutUs from '../components/Aboutus'
import AboutUs_view from '../components/Aboutus_view'
import AboutusTitles from '../components/AboutusTitles'
import Schemes from '../components/Schemes'
import Schemes_view from '../components/Schemes_view'
import SchemesTitles from '../components/SchemesTitles'
import NotificationTitles from '../components/Notification'
import Notification_view from '../components/Notification_view'
import Login_page from '../components/Login_page'
import Mini_about_us from '../components/Mini_about_us'
import Guidelines_view from '../components/Guidelines_view'
import GuidelinesTitles from '../components/GuidelinesTitles'
import Dashboard from '../cms/components/Dashboard'

// function App() {
//   return (
//     <div>
    

      
//       <Header />
//       <BrowserRouter>
//       <Routes>
//       <Route path="/" element={<Home />} />
//       <Route path="/guidelines" element={<Guidelines />} />
//       <Route path="/guidelines2" element={<Guidelines2 />} />
//       <Route path="/contactus" element={<Contactus />} />
//       <Route path="/gallery" element={<Gallery />} />
//           {/* <main className='content'> */}
//       {/* <Slider /> */}
//        {/* <Midcard /> */}
//       {/* <Mapelocation />  */}
//       {/* </main> */}
     
//       {/* <Route path="/guidlines">
//               <Guidlines />
//       </Route>   */}
//       </Routes>
//       </BrowserRouter>
      
//     <FooTer />
//     </div>
//   );
// }
function MyApp() {
  return (
    <div>
    
    <Router>
      
      <Header />
      
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/guidelines" element={<Guidelines />} />
      <Route path="/guidelines-view/:id" element={<Guidelines_view/>} /> 
      <Route path="/guideline-titles" element={<GuidelinesTitles />} />
      <Route path="/guidelines2" element={<Guidelines2 />} />
      <Route path="/contactus" element={<Contactus />} />
      <Route path="/gallery" element={<Gallery />} />
      <Route path="/login" element={<Dashboard />} />
      <Route path="/registration" element={<Registration />} />
      <Route path="/aboutus" element={<AboutUs />} />
      <Route path="/aboutus-view/:id" element={<AboutUs_view />} /> 
      <Route path="/aboutus-titles" element={<AboutusTitles />} /> 
      <Route path="/schemes" element={<Schemes />} />
      {/* <Route path="/schemes/:id" element={<Schemes />} /> */}
      <Route path="/schemes_view/:id" element={<Schemes_view />} />
      {/* <Route path="/:id/schemes-view" element={<Schemes_view />} />  */}
      <Route path="/schemes-titles" element={<SchemesTitles />} /> 
      <Route path="/:id/notification-view" element={<Notification_view />} /> 
      <Route path="/notification-titles" element={<NotificationTitles />} /> 
      <Route path="/login_part" element={<Login_page />} /> 
      <Route path="/mini_about_us" element={<Mini_about_us />} /> 

    
          {/* <main className='content'> */}
      {/* <Slider /> */}
       {/* <Midcard /> */}
      {/* <Mapelocation />  */}
      {/* </main> */}
     
      {/* <Route path="/guidlines">
              <Guidlines />
      </Route>   */}
      </Routes>
      
      
    <FooTer />
    </Router>
    </div>
  );
}


export default MyApp;
